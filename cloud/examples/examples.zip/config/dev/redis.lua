local root = {
    ["mj"] = {
        {
            host = "127.0.0.1",
            port = 6379,
            db   = 0,
            auth = "thOIFNORSjLfff"
        }
    }
}

return root